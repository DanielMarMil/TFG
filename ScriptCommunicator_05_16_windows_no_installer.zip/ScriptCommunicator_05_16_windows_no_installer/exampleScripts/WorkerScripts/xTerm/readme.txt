To execute the xTerm terminal:
- add xTerm.js in the script window
- download the extra libraries for your platform (https://sourceforge.net/projects/scriptcommunicator/files/AdditionalLibraries/ScriptWebView)
	- Windows and Linux: copy the libraries into the ScriptCommunicator folder 
	- Mac OS X: copy the libraries into ScriptCommunicator.app/Contents/Frameworks
	
	
	
Note: xTerm.js uses https://github.com/xtermjs/xterm.js executed by a ScriptWebView object (based on QWebView). 
The ScriptWebView Api is described in exampleScripts\WorkerScripts\CustomWidget\WebView\readme.txt.

